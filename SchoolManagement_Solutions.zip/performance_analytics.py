import heapq
class PerformanceAnalytics:
    def __init__(self):
        self.scores = {}  # student_id -> list of scores

    def add_score(self, student_id:int, subject:str, score:float):
        self.scores.setdefault(student_id, []).append((subject, score))

    def average(self, student_id:int):
        lst=self.scores.get(student_id,[])
        if not lst: return 0.0
        return sum(s for _,s in lst)/len(lst)

    def top_k(self, k=3):
        heap=[]
        for sid in self.scores:
            avg=self.average(sid)
            heapq.heappush(heap, (-avg, sid))
        res=[]
        for _ in range(min(k, len(heap))):
            avg_neg, sid = heapq.heappop(heap)
            res.append((sid, -avg_neg))
        return res
