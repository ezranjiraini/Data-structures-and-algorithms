from collections import deque
class Course:
    def __init__(self, code:str, capacity:int):
        self.code = code
        self.capacity = capacity
        self.enrolled = []
        self.waitlist = deque()

    def register(self, student_id:int):
        if len(self.enrolled) < self.capacity:
            self.enrolled.append(student_id)
            return "enrolled"
        else:
            self.waitlist.append(student_id)
            return "waitlisted"

    def process_waitlist(self):
        while len(self.enrolled) < self.capacity and self.waitlist:
            self.enrolled.append(self.waitlist.popleft())

    def remove(self, student_id:int):
        if student_id in self.enrolled:
            self.enrolled.remove(student_id)
            self.process_waitlist()
            return True
        try:
            self.waitlist.remove(student_id)
            return True
        except ValueError:
            return False
