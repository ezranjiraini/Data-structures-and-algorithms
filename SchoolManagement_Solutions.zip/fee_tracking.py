import time
class Payment:
    def __init__(self, student_id:int, amount:float, timestamp:float=None):
        self.student_id = student_id
        self.amount = amount
        self.timestamp = timestamp or time.time()
    def key(self):
        return (self.student_id, self.timestamp)

class BSTNode:
    def __init__(self, payment:Payment):
        self.payment = payment
        self.left = None
        self.right = None

class PaymentBST:
    def __init__(self):
        self.root = None

    def insert(self, payment:Payment):
        def _insert(node, p):
            if not node:
                return BSTNode(p)
            if p.key() < node.payment.key():
                node.left = _insert(node.left, p)
            else:
                node.right = _insert(node.right, p)
            return node
        self.root = _insert(self.root, payment)

    def inorder(self):
        out=[]
        def _in(node):
            if not node: return
            _in(node.left)
            out.append(node.payment)
            _in(node.right)
        _in(self.root)
        return out

    def total_for_student(self, student_id:int):
        s=0.0
        for p in self.inorder():
            if p.student_id==student_id:
                s+=p.amount
        return s
