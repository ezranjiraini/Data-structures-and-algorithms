# Demo runner that ties modules together with sample data
import json
from student_registry import Student, StudentRegistry
from course_scheduler import Course
from fee_tracking import Payment, PaymentBST
from library_system import Book, Library
from performance_analytics import PerformanceAnalytics

def load_sample(path='sample_data.json'):
    with open(path,'r') as f:
        return json.load(f)

def demo():
    data = load_sample()
    # students
    reg = StudentRegistry()
    for s in data['students']:
        reg.add_student(Student(s['id'], s['name'], s['year']))
    print('Registered students:', [s.to_dict() for s in reg.list_all()])

    # courses
    course = Course('CS101', capacity=2)
    for sid in data['course_registrations']:
        print('Register', sid, course.register(sid))
    print('Enrolled:', course.enrolled, 'Waitlist:', list(course.waitlist))

    # payments
    bst = PaymentBST()
    for p in data['payments']:
        bst.insert(Payment(p['student_id'], p['amount'], p['timestamp']))
    print('Payments inorder (student_id,amount):', [(x.student_id,x.amount) for x in bst.inorder()])
    # library
    lib = Library()
    for b in data['books']:
        lib.add_book(Book(b['isbn'], b['title'], b['copies']))
    print('Borrow CS book:', lib.borrow('978-0-123456-47-2'))
    print('Recent returns:', lib.recent_returns())

    # analytics
    pa = PerformanceAnalytics()
    for sc in data['scores']:
        pa.add_score(sc['student_id'], sc['subject'], sc['score'])
    print('Top performers:', pa.top_k(3))

if __name__=='__main__':
    demo()
