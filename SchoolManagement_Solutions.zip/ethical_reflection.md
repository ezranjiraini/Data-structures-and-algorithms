# Ethical Reflection
- Fairness: Course allocation uses FIFO; consider reservation quotas for disabled or priority students to ensure equity.
- Privacy: Store only necessary fields; in production encrypt sensitive fields and use role-based access.
- Transparency: Provide logs and clear criteria for allocation and analytics; allow appeals.
