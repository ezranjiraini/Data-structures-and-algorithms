# Performance Report (summary)
- Student Registry (dict + linked list): lookup O(1), insertion O(1) for dict, linked list insertion O(1). Remove from linked list O(n).
- Course Scheduling (deque + circular array): enqueue/dequeue O(1). Circular buffer gives O(1) indexing.
- Fee Tracking (BST): insert O(h), average O(n) traversal for reports; balanced tree (AVL) would give guaranteed O(log n).
- Library (dict + stack): lookup O(1), borrow/return O(1).
- Analytics (heap): top-k O(n + k log n).

Trade-offs discussed in full in submitted document.
