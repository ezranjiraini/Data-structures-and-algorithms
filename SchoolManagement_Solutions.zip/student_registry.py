from typing import Optional
class Student:
    def __init__(self, student_id:int, name:str, year:int):
        self.id = student_id
        self.name = name
        self.year = year
    def to_dict(self):
        return {"id":self.id,"name":self.name,"year":self.year}

class ListNode:
    def __init__(self, student:Student, nxt=None):
        self.student = student
        self.next = nxt

class StudentRegistry:
    # dict for quick lookup, singly linked list for insertion order
    def __init__(self):
        self.map = {}  # id -> Student
        self.head = None
        self.tail = None

    def add_student(self, student:Student):
        if student.id in self.map:
            raise KeyError("Student already exists")
        self.map[student.id] = student
        node = ListNode(student)
        if not self.head:
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node

    def find(self, student_id:int) -> Optional[Student]:
        return self.map.get(student_id)

    def remove(self, student_id:int):
        if student_id not in self.map:
            return False
        del self.map[student_id]
        # remove from linked list (O(n))
        prev = None
        cur = self.head
        while cur:
            if cur.student.id == student_id:
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                if cur is self.tail:
                    self.tail = prev
                return True
            prev = cur
            cur = cur.next
        return True

    def list_all(self):
        cur = self.head
        while cur:
            yield cur.student
            cur = cur.next
