# School Management System - Prototype

Run `python3 run_demo.py` to see a demo using sample_data.json
