class Book:
    def __init__(self, isbn:str, title:str, copies:int=1):
        self.isbn=isbn
        self.title=title
        self.copies=copies
        self.borrowed=0

class Library:
    def __init__(self):
        self.catalog = {}  # isbn -> Book
        self.return_stack = []  # stack of isbn for recent returns

    def add_book(self, book:Book):
        if book.isbn in self.catalog:
            self.catalog[book.isbn].copies += book.copies
        else:
            self.catalog[book.isbn] = book

    def borrow(self, isbn:str):
        b = self.catalog.get(isbn)
        if not b or b.copies - b.borrowed <= 0:
            return False
        b.borrowed += 1
        return True

    def return_book(self, isbn:str):
        b = self.catalog.get(isbn)
        if not b:
            return False
        if b.borrowed>0:
            b.borrowed-=1
        self.return_stack.append(isbn)
        return True

    def recent_returns(self, n=5):
        return self.return_stack[-n:][::-1]
